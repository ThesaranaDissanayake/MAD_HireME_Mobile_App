package com.example.hireme.models

data class PostModel(
    var postId: String? = null,
    var etTitle: String? = null,
    var etLocation: String? = null,
    var etAbout: String? = null,
    var etContact: String? = null
)